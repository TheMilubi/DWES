<?php
$fidelidad = [
    "1. Tu pareja parece estar más inquieta de lo normal sin ningún motivo aparente.",
    "2. Ha aumentado sus gastos de vestuario",
    "3. Ha perdido el interés que mostraba anteriormente por ti",
    "4. Ahora se afeita y se asea con más frecuencia (si es hombre) o ahora se arregla el pelo y se asea con más frecuencia (si es mujer)",
    "5. No te deja que mires la agenda de su teléfono móvil",
    "6. A veces tiene llamadas que dice no querer contestar cuando estás tú delante",
    "7. Últimamente se preocupa más en cuidar la línea y/o estar bronceado/a",
    "8. Muchos días viene tarde después de trabajar porque dice tener mucho más trabajo",
    "9. Has notado que últimamente se perfuma más",
    "10. Se confunde y te dice que ha estado en sitios donde no ha ido contigo"
];
?>